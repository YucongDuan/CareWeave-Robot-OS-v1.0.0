# Verification report — v1.0.0

Date: 2026-08-27

## Automated suite

Command:

```bash
PYTHONPATH=src pytest -q -W error::ResourceWarning
```

Result: **26 passed**.

Verified areas:

1. PBKDF2 password hashing and incorrect-password rejection.
2. Stop action always allowed.
3. Child secrecy/attachment manipulation blocked.
4. Elder diagnosis language blocked.
5. Approved navigation requires human approval.
6. Unapproved destination cannot be overridden by an approval click.
7. Memory requires active consent.
8. Raw API keys/private material blocked.
9. Health and authentication endpoints.
10. Automatic edition-specific care contract.
11. One-time robot enrollment token handling.
12. Mock adapter action completion.
13. Critical policy block and alert generation.
14. Child teach-back conversation path.
15. Emergency-language escalation.
16. Audit chain verification.
17. Proposed memory without consent.
18. Active memory with guardian consent.
19. Scheduled routine firing.
20. Subject data export.
21. Robot heartbeat, command lease and result lifecycle.
22. Invalid robot-token rejection.
23. Audit tamper detection.
24. Owner account provisioning and duplicate-email rejection.
25. Password rotation and old-password invalidation.
26. Viewer role restriction on subject creation.

Measured source coverage in the verification run: approximately **72% line coverage**. Network/hardware adapters are intentionally below that figure because the target devices were not available; they must be tested with vendor simulators or physical hardware.

## Package smoke test

- built `dikwp_careweave-1.0.0-py3-none-any.whl`;
- inspected Wheel contents for Python modules, dashboard files and default contracts;
- installed Wheel to an isolated target directory;
- ran `python -m dikwp_careweave doctor` against a fresh database;
- received valid audit chain and status `ok`;
- loaded `/`, `/static/app.js` and `/api/v1/health` from the installed package.

## Static checks

- Python compileall passed for core and Python bridges;
- JavaScript syntax check passed;
- ZIP/Wheel CRC checks are performed during final packaging;
- architecture SVG parsed and rendered to PNG.

## Not executed in this environment

- Docker image build, because no Docker/Podman runtime is present;
- Android Gradle build for temi;
- Pepper proprietary QiSDK build;
- ROS 2 runtime execution;
- Unitree SDK2 execution;
- Misty/Furhat physical network calls;
- collision, navigation, force, speed, battery or emergency-stop hardware tests;
- independent penetration test, privacy impact assessment, legal compliance review or third-party certification.
