# DIKWP CareWeave Robot OS v1.0.0 发布说明

发布日期：2026-08-27  
许可：Apache-2.0  
成熟度：产品化参考实现 / 付费设计试点底座

## 中文

本版本交付一套统一开源平台，而不是分别制作两个封闭机器人应用。CareWeave Elder面向老人自主陪护，CareWeave Grow面向儿童成长学习，两者共同使用Purpose合同、同意、记忆治理、确定性动作门控、人工审批、警报、机器人能力协商、命令回执和审计链。

### 已在软件环境中实际验证

- Python源码编译；
- 26项自动化测试；
- 资源连接关闭检查；
- Wheel构建及文件内容检查；
- Wheel安装后的`doctor`检查；
- 安装包中的Web控制台、静态资源和API健康检查；
- Mock机器人直接执行；
- 通用机器人令牌、心跳、命令租约和结果回执；
- 审计链完整性及篡改检测。

### 需要目标硬件验证

- Misty与Furhat网络适配器；
- ROS 2侧车；
- temi Android SDK模板；
- Pepper QiSDK模板；
- Unitree SDK2/ROS 2安全插件边界；
- 任何导航、机械臂、具身运动或远程呈现流程。

这些部分已经提供代码和边界，但本交付环境没有相应实机，不能声称已完成物理机器人验收。

### 产品边界

本版本不是医疗器械、急救派单系统、无人托育服务或认证的机器人安全控制器。它不会诊断、改变用药、自动配药、转账、开外门、抬举/约束人体，也不会允许机器人与儿童建立秘密或排他依恋。通用协议不输出轮速、关节值或扭矩。

## English

CareWeave v1.0.0 delivers one governed platform with two market-facing editions. Elder supports autonomy, routines, companionship and real-human escalation. Grow supports Socratic learning, teach-back evidence and guardian collaboration. Both share purpose contracts, consent, governed memory, deterministic action evaluation, human approval, robot capability negotiation, command receipts and a tamper-evident audit chain.

The core software, mock execution, robot polling protocol, package installation and API were tested in this delivery environment. Hardware-specific integrations require the named robot/SDK and site testing. The release makes no medical-device, autonomous-childcare, emergency-dispatch, certification or guaranteed market-leadership claim.
